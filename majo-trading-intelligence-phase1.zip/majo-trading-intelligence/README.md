# MAJO TRADING INTELLIGENCE

Phase 1 scaffold. This repository deliberately starts with **no market data and no trading connectivity**. Empty credentials produce `NOT_CONNECTED`; no prices or candles are fabricated.

## Phase 1 status
- Monorepo skeleton: web (Next.js), API (FastAPI), worker, Windows-only MT5 bridge, shared types, indicator package, infra and docs.
- `/api/v1/health` and `/api/v1/health/adapters` implemented.
- `mti data:selftest` reports configuration and performs a bounded connectivity check only for configured HTTP/WebSocket endpoints; no keys means an honest failure / NOT_CONNECTED result.
- Docker Compose includes TimescaleDB, Redis, API, worker and web.

## Start locally
1. Copy `.env.example` to `.env`. Leave keys blank for the initial safe boot.
2. Run `docker compose -f infra/docker-compose.yml --env-file .env up --build` from the repository root.
3. API health: `http://localhost:8000/api/v1/health`; adapter health: `http://localhost:8000/api/v1/health/adapters`; web: `http://localhost:3000`.
4. For CLI self-test outside Docker: from `apps/api`, install `pip install -e .`, then run `mti data:selftest`.

The current self-test is a connectivity/configuration smoke test, not proof that a provider account permits market-data access or redistribution. Provider-specific protocol verification belongs in Phase 3.

## Important architecture constraints
- MT5 bridge requires Windows, a running and logged-in MetaTrader 5 terminal, and the MetaTrader5 Python package. It cannot run on Vercel, Railway, Render, or a Linux/serverless host. Production deployment requires a Windows VPS; API-to-bridge traffic must use authenticated HTTPS, bearer token and IP allowlisting.
- ForexFactory has no official public API; use a verified alternative or maintained wrapper only after reviewing terms.
- Alpha Vantage free tier is limited to 25 calls/day and must never be used for live polling.
- LSE free tier is documented here as 100 requests/minute; Phase 3 must verify current provider terms, prefer WebSocket, and use a Redis-shared REST token bucket capped at 60% of documented limits.
- Provider terms govern redistribution; do not re-export raw feeds to third parties.
- Backtests are hypothetical and subject to lookahead, survivorship and cost-model limitations.

## Phases
Phase 1 is scaffold only. Indicator calculations, live provider adapters, signal engine, backtests, full auth/RBAC, risk enforcement, notifications and MT5 order routing are not yet implemented. Live execution is disabled by default and is not available in this phase.
