"""Provider-neutral adapter health registry. No provider SDKs or fabricated quotes."""
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Optional
from .config import settings

@dataclass
class AdapterHealth:
    provider: str
    configured: bool
    connected: bool = False
    status: str = "NOT_CONNECTED"
    last_tick_utc: Optional[str] = None
    latency_ms: Optional[float] = None
    error: Optional[str] = "Credentials or endpoint not configured"

    def as_dict(self):
        return asdict(self)

class AdapterRegistry:
    def __init__(self):
        self._adapters = {
            "LSE": AdapterHealth("LSE", bool(settings.lse_api_key and settings.lse_ws_url), error="LSE API key and WebSocket URL are required"),
            "FCSAPI": AdapterHealth("FCSAPI", bool(settings.fcsapi_key), error="FCSAPI key is required"),
            "Alpha Vantage": AdapterHealth("Alpha Vantage", bool(settings.alphavantage_key), error="Alpha Vantage key is required; historical/cross-check only, never live polling"),
            "News/Calendar": AdapterHealth("News/Calendar", bool(settings.news_api_key), error="News/calendar provider key is required"),
            "MT5 Bridge": AdapterHealth("MT5 Bridge", bool(settings.mt5_bridge_enabled and settings.mt5_bridge_url and settings.mt5_bridge_token), error="Bridge disabled or URL/token not configured"),
        }

    def health(self):
        # Configuration is not connectivity. No adapter is marked connected until a
        # provider-specific runtime handshake is implemented and verified in Phase 3/8.
        return [item.as_dict() for item in self._adapters.values()]

registry = AdapterRegistry()
