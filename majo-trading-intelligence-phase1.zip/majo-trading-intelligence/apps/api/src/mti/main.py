from datetime import datetime, timezone
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from . import __version__
from .config import settings
from .adapters import registry

app = FastAPI(title="MAJO TRADING INTELLIGENCE API", version=__version__)
origins = [x.strip() for x in settings.model_config.get("cors_origins", "http://localhost:3000").split(",") if x.strip()] if isinstance(settings.model_config.get("cors_origins"), str) else ["http://localhost:3000"]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=["GET"], allow_headers=["*"])

@app.get("/api/v1/health")
async def health():
    return {"status": "ok", "service": "mti-api", "version": __version__, "timestamp_utc": datetime.now(timezone.utc).isoformat()}

@app.get("/api/v1/health/adapters")
async def adapter_health():
    items = registry.health()
    return {"timestamp_utc": datetime.now(timezone.utc).isoformat(), "adapters": items, "data_available": any(a["connected"] for a in items), "message": "DATA SOURCE NOT CONNECTED — no verified provider handshake has been completed"}
