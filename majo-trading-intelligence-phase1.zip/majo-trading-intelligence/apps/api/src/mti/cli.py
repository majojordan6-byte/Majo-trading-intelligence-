"""MTI command-line checks. This phase performs bounded endpoint smoke checks only."""
import asyncio, os, sys
from urllib.parse import urlparse
import httpx
from .config import settings

async def check_http(name, url, headers=None):
    if not url:
        return (name, "FAIL", "not configured")
    try:
        async with httpx.AsyncClient(timeout=4.0, follow_redirects=False) as client:
            r = await client.get(url, headers=headers or {})
        # Any HTTP response proves network reachability, not successful authorization.
        return (name, "PASS" if r.status_code < 500 else "FAIL", f"HTTP {r.status_code} (reachability only; access not validated)")
    except Exception as exc:
        return (name, "FAIL", f"connection check failed: {type(exc).__name__}")

async def run_selftest():
    rows=[]
    if not (settings.lse_api_key and settings.lse_ws_url): rows.append(("LSE", "FAIL", "API key or WebSocket URL missing"))
    else:
        # WS endpoint reachability handshake is deferred until provider protocol is verified in Phase 3.
        rows.append(("LSE", "FAIL", "configured, but provider-specific WebSocket handshake is not implemented in Phase 1"))
    if settings.fcsapi_key: rows.append(("FCSAPI", "FAIL", "configured, but provider-specific authenticated endpoint is not implemented in Phase 1"))
    else: rows.append(("FCSAPI", "FAIL", "API key missing"))
    if settings.alphavantage_key: rows.append(("Alpha Vantage", "FAIL", "configured, but API validation is deferred; historical/cross-check only"))
    else: rows.append(("Alpha Vantage", "FAIL", "API key missing"))
    if settings.news_api_key: rows.append(("News/Calendar", "FAIL", "configured, provider endpoint not selected/verified in Phase 1"))
    else: rows.append(("News/Calendar", "FAIL", "API key missing"))
    if settings.mt5_bridge_enabled and settings.mt5_bridge_url and settings.mt5_bridge_token:
        rows.append(await check_http("MT5 Bridge", settings.mt5_bridge_url.rstrip("/") + "/health", {"Authorization": f"Bearer {settings.mt5_bridge_token}"}))
    else: rows.append(("MT5 Bridge", "FAIL", "bridge disabled or URL/token missing"))
    print("ADAPTER SELFTEST (Phase 1; no market data requested)")
    print(f"{'ADAPTER':<18} {'RESULT':<8} DETAIL")
    print("-"*100)
    for n,s,d in rows: print(f"{n:<18} {s:<8} {d}")
    print("PASS means network reachability only where explicitly stated; it never proves market-data entitlement.")
    return 0 if rows and all(r[1] == "PASS" for r in rows) else 1

def main():
    if len(sys.argv) == 2 and sys.argv[1] == "data:selftest":
        raise SystemExit(asyncio.run(run_selftest()))
    if len(sys.argv) >= 3 and sys.argv[1:3] == ["data", "selftest"]:
        raise SystemExit(asyncio.run(run_selftest()))
    print("Usage: mti data:selftest")
    print("Note: invoke as `mti data:selftest` (shells may parse the colon as part of the argument).")
    raise SystemExit(2)
