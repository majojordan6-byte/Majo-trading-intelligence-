from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="MTI_", env_file="../../.env", extra="ignore")
    env: str = "local"
    log_level: str = "INFO"
    lse_api_key: str = ""
    lse_ws_url: str = ""
    fcsapi_key: str = ""
    alphavantage_key: str = ""
    news_api_key: str = ""
    mt5_bridge_url: str = ""
    mt5_bridge_token: str = ""
    mt5_bridge_enabled: bool = False

settings = Settings()
