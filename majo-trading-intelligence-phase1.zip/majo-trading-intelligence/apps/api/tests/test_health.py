from fastapi.testclient import TestClient
from mti.main import app

def test_health():
    r=TestClient(app).get("/api/v1/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_adapters_never_claim_connected_without_handshake():
    r=TestClient(app).get("/api/v1/health/adapters")
    assert r.status_code == 200
    body=r.json()
    assert body["data_available"] is False
    assert all(not a["connected"] and a["status"] == "NOT_CONNECTED" for a in body["adapters"])
