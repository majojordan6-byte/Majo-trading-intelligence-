import type { Metadata } from "next";
import "./styles.css";
export const metadata: Metadata = { title: "MAJO TRADING INTELLIGENCE", description: "Institutional-style market analysis terminal" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
