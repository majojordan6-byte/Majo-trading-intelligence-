"use client";
import { useEffect, useState } from "react";
type Adapter = {provider:string; configured:boolean; connected:boolean; status:string; error:string|null; last_tick_utc:string|null; latency_ms:number|null};
type Health = {timestamp_utc:string; adapters:Adapter[]; data_available:boolean; message:string};
const api = process.env.NEXT_PUBLIC_MTI_API_BASE || "http://localhost:8000";
export default function Home() {
 const [health,setHealth]=useState<Health|null>(null); const [err,setErr]=useState("API health has not been verified yet.");
 useEffect(()=>{ let alive=true; fetch(`${api}/api/v1/health/adapters`,{cache:"no-store"}).then(async r=>{if(!r.ok) throw new Error(`API returned HTTP ${r.status}`); return r.json()}).then(d=>{if(alive){setHealth(d);setErr("")}}).catch(e=>{if(alive)setErr(String(e.message||e))}); return ()=>{alive=false}},[]);
 return <main className="shell"><header className="top"><div className="brand"><span className="mark">M</span><div><b>MAJO TRADING INTELLIGENCE</b><small>MARKET TERMINAL · PHASE 1 SCAFFOLD</small></div></div><div className="pill"><i/>LIVE DATA DISABLED</div></header>
 <section className="banner"><b>DATA SOURCE NOT CONNECTED</b><span>No verified market-data connection. Quotes, candles, signals, news and calendar are intentionally empty.</span></section>
 <div className="layout"><nav className="nav">{["Dashboard","Charts","Signals","Calendar","News","Journal","Analytics","Risk","Alerts","Settings"].map((x,i)=><div className={i===0?"navitem active":"navitem"} key={x}>{x}</div>)}</nav>
 <section className="main"><div className="heading"><div><p className="eyebrow">WORKSPACE / OVERVIEW</p><h1>Market overview</h1></div><span className="tag">NO VERIFIED FEED</span></div>
 <div className="empty"><div className="emptyicon">∅</div><h2>Waiting for a verified data source</h2><p>There are no prices or candles to display. Configure a provider and complete its runtime handshake before this workspace can show market data.</p></div>
 <div className="cards"><article><label>MARKET QUOTES</label><strong>—</strong><p>Unavailable · no source</p></article><article><label>AI SIGNALS</label><strong>WAIT</strong><p>No signal generated without verified candles</p></article><article><label>EXECUTION</label><strong>DISABLED</strong><p>Live execution is not implemented in Phase 1</p></article></div>
 <section className="panel"><div className="panelhead"><h2>Adapter health</h2><span>{health?`Checked ${new Date(health.timestamp_utc).toLocaleString()}`:"Not checked"}</span></div>{err&&<p className="error">API unavailable: {err}</p>}{(health?.adapters||[]).map(a=><div className="adapter" key={a.provider}><div><b>{a.provider}</b><small>{a.error||"No verified handshake"}</small></div><span className="state">{a.connected?"CONNECTED":"NOT_CONNECTED"}</span></div>)}</section>
 <p className="disclaimer">Technical analysis alerts are not financial advice. Confidence scores, when implemented, will be model outputs, not predictions. Leveraged trading carries a high risk of loss.</p></section></div>
 <footer>Data: none verified · Last refresh: {health?new Date(health.timestamp_utc).toISOString():"not available"} · v0.1.0 · Past performance does not predict future results.</footer></main>
}
