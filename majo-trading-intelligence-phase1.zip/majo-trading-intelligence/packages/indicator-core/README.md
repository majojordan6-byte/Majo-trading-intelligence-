Pure Python indicator functions will be added in Phase 2. No I/O, provider SDKs or future-bar access. Golden tests must use documented reference values with tolerance <= 1e-6.
