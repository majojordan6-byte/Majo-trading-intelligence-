Shared TypeScript types are generated from the FastAPI OpenAPI schema in a later phase. Do not hand-maintain duplicate API contracts once generation is implemented.
