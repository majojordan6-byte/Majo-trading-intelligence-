# MT5 bridge deployment

The MetaTrader5 Python package requires Windows and a running, logged-in terminal. The bridge cannot run on Vercel, Railway, Render, or a Linux-only/serverless host. Use a separate Windows VPS in production. API-to-bridge communication requires HTTPS, bearer token and IP allowlisting; credentials remain on the bridge host. The Phase 1 repository contains no functional order routing.
