# Data provenance

No provider is considered connected until a provider-specific runtime handshake succeeds. Configured credentials alone do not mean connected. Unknown data is represented as empty state. Every future market record must include source, UTC timestamp, local timestamp and latency. Disconnects must mark prior data stale rather than live. Alpha Vantage is historical/cross-check only and must not be used in live polling.
