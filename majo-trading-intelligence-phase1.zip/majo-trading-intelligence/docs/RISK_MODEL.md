# Risk model

Live trading is disabled by default. No live execution path exists in Phase 1. Future order services must enforce risk limits server-side, require completed backtest and paper-trading gates, require explicit acknowledgement and typed per-order CONFIRM, and write a hash-chained audit record before sending any order. No profit is guaranteed.
