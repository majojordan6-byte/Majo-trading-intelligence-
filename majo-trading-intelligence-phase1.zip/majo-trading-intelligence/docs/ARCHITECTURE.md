# Architecture

Phase 1 uses a Next.js web shell, FastAPI API, worker process, Redis, and TimescaleDB via Docker Compose. Provider SDKs belong only in adapter modules. All internal symbols will be canonical IDs. API and worker share Redis for rate-limit accounting in Phase 3. MT5 is a separate Windows service and is not hosted alongside Linux services.
