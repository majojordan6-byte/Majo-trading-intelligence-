# MAJO TRADING INTELLIGENCE engineering rules

Apply the following rules to every file:
1. NEVER simulate, mock, or fabricate live market data. Unconfigured or unverified adapter → UI shows "DATA SOURCE NOT CONNECTED" with the reason. No placeholder prices, no sample candles, no "demo data" toggle that masquerades as live.
2. NEVER claim an integration works unless verified at runtime. For MT5: mt5.initialize() returns True, mt5.last_error() checked, mt5.account_info() non-null, and order_send().retcode validated before reporting success.
3. EVERY price, signal, news item, and calendar event renders SOURCE + TIMESTAMP (local + UTC) + latency indicator (green <500ms, amber <2s, red >=2s). On disconnect: "STALE — LAST UPDATE: <ts>". Never a frozen price styled as live.
4. NEVER guarantee profits. Confidence scores are labeled "model output, not a prediction". Every signal, backtest, and execution screen carries a risk warning. Backtest reports MUST show drawdowns, losing streaks, and out-of-sample degradation.
5. Live trading DISABLED BY DEFAULT, enforced server-side, not just in UI. Enabling requires ALL of: verified MT5 connection + a completed backtest run + a completed paper-trading period + explicit user risk acknowledgement + per-order typed "CONFIRM" + immutable audit entry.
6. All credentials server-side only. Never in frontend bundles, logs, source control, or error messages. MT5 credentials live ONLY on the bridge host.
7. Unknown or unavailable data = explicit empty state with a stated reason. Never guess, never interpolate silently, never backfill with fake values.
8. Do not invent API endpoints, library functions, or broker behaviors. If a detail is uncertain, state the assumption explicitly and flag it for verification rather than writing plausible-looking code.
