"""Phase 1 worker placeholder: deliberately performs no polling or trading."""
import os, time
print("MTI worker scaffold started. No provider configured; market polling and order execution are disabled.", flush=True)
while True:
    time.sleep(60)
